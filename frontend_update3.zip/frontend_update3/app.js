const express = require('express'); 
const { MongoClient, ObjectId } = require('mongodb'); 
const cors = require('cors'); 
const path = require('path'); 
const app = express(); 
const port = 3000; 
 
const url = 'mongodb://localhost:27017/';
const dbName = 'employees';
const collectionName = 'employee_info';
 
let db; 

//function for connecting to database
async function connectToDatabase() { 
  const client = await MongoClient.connect(url);   
db = client.db(dbName); 
} 
 
app.use(express.json()); 
app.use(cors()); 
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

//function to get employees according to the filter and return as an array
async function getEmployees(filter){
    if (filter){
      //iterates through the filter object to delete any keys with empty values
      Object.keys(filter).forEach(key => {
        if (!filter[key]){
          delete filter[key];
        }
      });
    }
    //if no filter is provided, return all records
    const employees = await db.collection(collectionName).find(filter || {}).toArray();
    //returns array of employees
    return employees;
}

//route for displaying the index page
app.get('/', (req, res) => {
      getEmployees().then( //calls the getEmployees function and renders the index with the result 
    result => res.render('index', {result})); 
});

//route for filtering employee records
app.post('/filter', async (req, res) => {
    const filter = req.body;
    console.log(filter);
    getEmployees(filter).then(
      result => {
        //if result array from getEmployees is empty, return 404 status
        if (result.length === 0) {
          console.log('No records found.');
          return res.status(404).send('No records found.');
        } else {
          //render index page with the filtered array
          res.status(200).render('index', {result});
        }
      }
    );
});

//route for acessing the edit controls of a specific employee record 
app.get('/find', async (req, res) => { 
  const empid = req.query.empid; 
  try {   
    if (!db) { 
      console.log('Database connection is not established yet.'); 
      return res.status(500).json({ error: 'Database connection is not ready.' }); 
    } 
    const employee = await db.collection(collectionName).findOne({ empid: empid }); 
    if (employee) { 
      //if employee is found within the mongodb collection, render update page with specific employee data
      console.log('Editing employee:', employee);
      res.status(200).render('update', { employee });

    } else { 
      //if employee is not found
      console.log('No employee found with the provided empid.'); 
      //redirect to index page
      res.redirect('/');
    } 
  } catch (err) { 
    console.error('Error searching for employee:', err); 
    res.status(500).send('Error searching for employee.');
  }
}); 

//route for displaying the add employee page
app.get('/add', (req, res) => {
  res.render('add');
});

//route for displaying the login page
app.get('/login', (req, res) => {
  res.render('login');
});

//route for displaying the registration page
app.get('/registration', (req, res) => {
  res.render('registration');
});

//route for inserting an employee record into the collection
app.post('/insert', async (req, res) => { 
  //initialize empid at 0
  let empid = 0; 
  const { empname, position, department, salary } = req.body;   
  console.log('Received request body:', req.body); 
  //checks mongodb to see if there is an existing index within the collection
  //takes the last record within the collection
  const lastRecord = await db.collection(collectionName).find().limit(1).sort({$natural:-1}).toArray(); 
  if (lastRecord.length > 0){
    //if last record is found, parse the index's empid
   const lastEmpid = parseInt(lastRecord[0].empid);
   //auto-increment empid based on the last record's value
   empid = lastEmpid + 1;
 } 
  try { 
    if (!db) { 
      console.log('Database connection is not established yet.'); 
      return res.status(500).json({ error: 'Database connection is not ready.' }); 
    }
    //command to insert the employee data into the collection 
    await db.collection(collectionName).insertOne({       empid: empid.toString(),       empname,       position,       department,       salary, 
    }); 
 
    console.log('Record inserted successfully!'); 
    res.status(201).json({ message: 'Record inserted successfully!' }); 
  } catch (err) { 
    //trapping for insertion errors
    console.error('Error inserting record:', err); 
    res.status(500).json({ error: 'An error occurred while inserting the record.' });   } 
}); 

app.post('/update', async (req, res) => {
  const {empid, empname, position, department, salary } = req.body;
  //logs update values into the console
  console.log('Update values:', req.body);
  try { 
      
    if (!db) { 
      console.log('Database connection is not established yet.'); 
      return res.status(500).json({ error: 'Database connection is not ready.' }); 
    } 
 
    const updateQuery = { empid };
    //uses $set operator to update values of fields in a document 
    const updateValues = { $set: { empname, position, department, salary } }; 
    //executes async record update
    const result = await db.collection(collectionName).updateOne(updateQuery, updateValues); 
 
    if (result.matchedCount > 0) { 
      console.log('Document updated successfully.'); 
      res.status(200).json({ message: 'Document updated successfully!' });  
    } else { 
      console.log('No document found with the provided empid.'); 
      res.status(404).json({ error: 'No document found with the provided empid.' }); 
    } 
  } catch (err) { 
    console.error('Error updating document:', err); 
    res.status(500).json({ error: 'An error occurred while updating the document.' }); 
  } 
}); 

//route for deleting an employee record from the collection
app.post('/delete', async (req, res) => {   
  const empid = req.body.empid; 
  try {  
    if (!db) { 
      console.log('Database connection is not established yet.'); 
      return res.status(500).json({ error: 'Database connection is not ready.' }); 
    } 
    const deleteQuery = { empid }; 
    //delete query to find the document with the specified empid and delete it
    const result = await db.collection(collectionName).deleteOne(deleteQuery); 

    if (result.deletedCount > 0) { 
      console.log('Document deleted successfully.'); 
      res.status(200).json({ message: 'Document deleted successfully!' }); 
    } else { 
      console.log('No document found with the provided empid.'); 
      res.status(404).json({ error: 'No document found with the provided empid.' }); 
    } 
  } catch (err) { 
    console.error('Error deleting document:', err); 
    res.status(500).json({ error: 'An error occurred while deleting the document.' });   } 
}); 

 
connectToDatabase() 
  .then(() => {     app.listen(port, () => { 
      console.log(`Server is running on http://localhost:${port}`); 
    }); 
  }) 
  .catch((err) => { 
    console.error('Error connecting to MongoDB:', err); 
  });
