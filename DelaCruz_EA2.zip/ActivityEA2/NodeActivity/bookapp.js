const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({extended : true}));
app.use(bodyParser.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');

const books = [
    { id: 1, imgUrl: "wings.jpg", featured: true, title: 'The Wings', author: 'Yi Sang', price:1939},
    { id: 2, imgUrl: "faust.jpg", featured: true, title: 'Goethes Faust', author: 'Johann Wolfgang von Goethe', price:179},
    { id: 3, imgUrl: "don.jpg", featured: false, title: 'Don Quixote', author: 'Miguel de Cervantes', price:1599},
    { id: 4, imgUrl: "hellscreen.jpg", featured: false, title: 'Hell Screen', author: ' Ryūnosuke Akutagawa', price:199},
    { id: 5, imgUrl: "stranger.jpg", featured: true, title: 'The Stranger', author: ' Albert Camus', price:1949},
    { id: 6, imgUrl: "redchamber.jpg", featured: false, title: 'Dreams of the Red Chamber', author: ' Cao Xueqin', price:1819},
    { id: 7, imgUrl: "wuthering.jpg", featured: true, title: 'Wuthering Heights', author: 'Emily Bronte', price:879},
    { id: 8, imgUrl: "mobydick.jpg", featured: true, title: 'Moby Dick', author: 'Herman Melville', price:859},
    { id: 9, imgUrl: "crime.jpg", featured: false, title: 'Crime and Punishment', author: 'Fyodor Dostoevsky', price:1599},
    { id: 10, imgUrl: "demian.jpg", featured: false, title: 'Demian', author: 'Hermann Hesse', price:919},
    { id: 11, imgUrl: "odyssey.jpg", featured: false, title: 'Odyssey', author: 'Homer', price:1809},
    { id: 12, imgUrl: "metamorphosis.jpg", featured: false, title: 'The Metamorphosis', author: 'Franz Kafka', price:919}
];
var cart = [];
app.get('/', (req, res) => {
    res.render('home', { books});
});

app.post('/cart/add', (req, res) => {
    const id = req.body;
    const book = books.find(b => b.id == id.bookId);
    const bookAdded = cart.find(c => c.id == book.id);
    if (bookAdded){
        bookAdded.quantity += 1;
    } else{
        cart.push({...book, quantity: 1});
    }
    res.sendStatus(200);
});
app.post('/cart/remove', (req, res) => {
    const id = req.body;
    const book = cart.find(c => c.id == id.bookId);
    if (book && book.quantity > 1){
        book.quantity -= 1;
    } else if (book.quantity == 1){
        const newCart = cart.filter(c => c.id != id.bookId);
        cart = newCart;
    }
    res.sendStatus(200);
})
app.post('/cart/clear', (req, res) => {
    cart = [];
    res.sendStatus(200); 
});
app.get('/book', (req, res) => {
    res.render('books', {books})
});
app.get('/cart', (req, res) => {
    res.render('cart', { cart });
});

app.listen(PORT, () =>{
    console.log(`Server running on http://localhost:${PORT}`);
});