const express = require('express'); 
const { MongoClient, ObjectId } = require('mongodb'); 
const cors = require('cors'); 
const path = require('path'); 
const app = express(); 
const port = 3000; 
//used for login state management
const session = require('express-session');
 
const url = 'mongodb://localhost:27017/';
const dbName = 'employees';
const collectionName = 'employee_info';

//credentials for admin login
const adminName = '123456789';
const adminPass = 'admin';
 
let db; 

//function for connecting to database
async function connectToDatabase() { 
  const client = await MongoClient.connect(url);   
db = client.db(dbName); 
} 
 
app.use(express.json()); 
app.use(cors()); 
app.use(session({
  secret: "Kaloi",
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false }
}))

app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

//function to get employees according to the filter and return as an array
async function getEmployees(filter){
    if (filter){
      //iterates through the filter object to delete any keys with empty values
      Object.keys(filter).forEach(key => {
        if (!filter[key]){
          delete filter[key];
        } else{
          filter[key] = {$regex: filter[key], $options: 'i'}; //adds regex to filter values for case-insensitive search
        }
      });
    }
    //if no filter is provided, return all records
    const employees = await db.collection(collectionName).find(filter || {}).toArray();
    //returns array of employees
    return employees;
}

//ensures that the empid field in the employee_info collection is unique
async function ensureUniqueIndex() {
await db.collection(collectionName).createIndex({ empid: 1 }, { unique: true });
}

//express middleware used for ensuring that the user is logged in before accessing protected routes
function requireLogin(req, res, next) {
  if (!req.session.user) {
    // If the user is not logged in, redirect to the login page
    console.log('User not logged in, redirecting to login page.');
    req.session.destroy();
    return res.redirect('/');
  }
  next();
}

//route for displaying the login page
app.get('/', (req, res) => {
  res.render('login');
});

//route for displaying the register page
app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/login', async (req, res) => {
  const {empid, emppass} = req.body;
  console.log('Received:', { empid, emppass });
  if (empid.trim() === adminName && emppass.trim() === adminPass){
    console.log("Admin login successful, redirecting...");
    req.session.user = { empid: empid.trim(), isAdmin: true };
    return res.redirect('/index');
  }
  await db.collection(collectionName).find({"empid": empid, "emppass": emppass}).toArray().then(
    result => {
      console.log('Login result:', result);
      if (result.length > 0){
        req.session.user = { empid: empid.trim(), isAdmin: false };
        return res.status(200).render('home', {result: result[0]});
      } else {
        return res.status(401).render('login', {error: 'Invalid credentials. Please try again.'});
      }
    }
  );
});

//route for displaying the index page
app.get('/index', requireLogin, (req, res) => {
    if(!req.session.user.isAdmin){
      return res.redirect('/'); //if user is not admin, redirect to login page
    }
    getEmployees().then( //calls the getEmployees function and renders the index with the result 
    result => res.render('index', {result})); 
});

//route for filtering employee records
app.post('/filter', requireLogin, async (req, res) => {
    const filter = req.body;
    console.log(filter);
    getEmployees(filter).then(
      result => {
        //if result array from getEmployees is empty, return 404 status
        if (result.length === 0) {
          console.log('No records found.');
          return res.status(404).send('No records found.');
        } else {
          //render index page with the filtered array
          res.status(200).render('index', {result});
        }
      }
    );
});

//route for acessing the edit controls of a specific employee record 
app.get('/find', requireLogin, async (req, res) => { 
  if(!req.session.user.isAdmin){
      return res.redirect('/'); //if user is not admin, redirect to login page
    }
  try {   
    if (!db) { 
      console.log('Database connection is not established yet.'); 
      return res.status(500).json({ error: 'Database connection is not ready.' }); 
    } 
    const empid = req.query.empid;
const empidLower = empid.toLowerCase();
const employee = await db.collection(collectionName).findOne({ empid: empidLower });
    if (employee) { 
      //if employee is found within the mongodb collection, render update page with specific employee data
      console.log('Editing employee:', employee);
      res.status(200).render('update', { employee });

    } else { 
      //if employee is not found
      console.log('No employee found with the provided empid.'); 
      //redirect to index page
      res.redirect('/index');
    } 
  } catch (err) { 
    console.error('Error searching for employee:', err); 
    res.status(500).send('Error searching for employee.');
  }
}); 

//route for displaying the add employee page
app.get('/add', (req, res) => {
  if(!req.session.user.isAdmin){
      return res.redirect('/'); //if user is not admin, redirect to login page
    }
  res.render('add');
});

//route for inserting an employee record into the collection
app.post('/insert', async (req, res) => { 
  const { empid, empname, position, department, salary, emppass } = req.body;   
  console.log('Received request body:', req.body);  
  try { 
    if (!db) { 
      console.log('Database connection is not established yet.'); 
      return res.status(500).json({ error: 'Database connection is not ready.' }); 
    }
    //command to insert the employee data into the collection 
    await db.collection(collectionName).insertOne({       empid: empid.toLowerCase(),       empname,       position,       department,       salary, emppass,
    }); 
 
    console.log('Record inserted successfully!'); 
    res.status(201).json({ message: 'Record inserted successfully!' }); 
  } catch (err) { 
    console.error('Error inserting record:', err);
    if (err.code == 11000) {
      //if user attempts to insert duplicate empid
      console.error('Duplicate key error:', err);
      return res.status(400).json({ message: 'Employee ID already exists.' });
    }
    res.status(500).json({ message: 'An error occurred while inserting the record.' });   } 
}); 

app.post('/update', requireLogin, async (req, res) => {
  const {empid, empname, position, department, salary } = req.body;
  //logs update values into the console
  console.log('Update values:', req.body);
  try { 
      
    if (!db) { 
      console.log('Database connection is not established yet.'); 
      return res.status(500).json({ error: 'Database connection is not ready.' }); 
    } 
 
    const updateQuery = { empid };
    //uses $set operator to update values of fields in a document 
    const updateValues = { $set: { empid, empname, position, department, salary } }; 
    //executes async record update
    const result = await db.collection(collectionName).updateOne(updateQuery, updateValues); 
 
    if (result.matchedCount > 0) { 
      console.log('Document updated successfully.'); 
      res.status(200).json({ message: 'Document updated successfully!' });  
    } else { 
      console.log('No document found with the provided empid.'); 
      res.status(404).json({ error: 'No document found with the provided empid.' }); 
    } 
  } catch (err) { 
    console.error('Error updating document:', err); 
    res.status(500).json({ error: 'An error occurred while updating the document.' }); 
  } 
}); 

//route for deleting an employee record from the collection
app.post('/delete', requireLogin, async (req, res) => {   
  const empid = req.body.empid; 
  try {  
    if (!db) { 
      console.log('Database connection is not established yet.'); 
      return res.status(500).json({ error: 'Database connection is not ready.' }); 
    } 
    const deleteQuery = { empid }; 
    //delete query to find the document with the specified empid and delete it
    const result = await db.collection(collectionName).deleteOne(deleteQuery); 

    if (result.deletedCount > 0) { 
      console.log('Document deleted successfully.'); 
      res.status(200).json({ message: 'Document deleted successfully!' }); 
    } else { 
      console.log('No document found with the provided empid.'); 
      res.status(404).json({ error: 'No document found with the provided empid.' }); 
    } 
  } catch (err) { 
    console.error('Error deleting document:', err); 
    res.status(500).json({ error: 'An error occurred while deleting the document.' });   } 
}); 

app.get('/home', requireLogin, (req, res) => {
  res.render('home', { result: req.session.user });
});

app.get('/logout', (req, res) => {
  //destroys session and redirects to the login page
  req.session.destroy(() => {
    console.log('Logout successful');
    res.redirect('/');
  });
});


 
connectToDatabase() 
  .then(async () => {
    //call ensureUniqueIndex to make employee ID field unique    
    await ensureUniqueIndex(); 
    app.listen(port, () => { 
      console.log(`Server is running on http://localhost:${port}`); 
    }); 
  }) 
  .catch((err) => { 
    console.error('Error connecting to MongoDB:', err); 
  });
