const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = process.env.PORT || 3000;

const { MongoClient } = require("mongodb"); 
const url = 'mongodb://127.0.0.1:27017';
const dbName = 'hospitaldb';
const collectionName = 'patient_info';

let db;
// const client = new MongoClient(url); 
async function connectToDB() { 
  try { 
    const client = await MongoClient.connect(url, {useUnifiedTopology: true});
    db = client.db(dbName);
    console.log("Connected to MongoDB!"); 
  } catch (error) { 
    console.error("Error connecting to MongoDB:", error); 
  } 
} 
connectToDB(); 

async function getData(){
  const client = await MongoClient.connect(url, {useUnifiedTopology: true});
  db = client.db(dbName);
  const data = await db.collection('patient_info').find().toArray();
  return data;
}

app.use(bodyParser.urlencoded({extended : true}));
app.use(bodyParser.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');


app.get('/', (req, res) => {
    const patients = getData();
    patients.then(
    result => res.render('index', { result }));
});

app.listen(PORT, () =>{
    console.log(`Server running on http://localhost:${PORT}`);
});