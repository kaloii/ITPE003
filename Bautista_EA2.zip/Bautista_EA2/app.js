const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({extended : true}));
app.use(bodyParser.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');

const books = [
    { id: 1, imgUrl: "richpoor.jpg", featured: true, title: 'Rich Dad Poor Dad', author: 'Robert Kiyosaki', price:500},
    { id: 2, imgUrl: "prince.jpg", featured: true, title: 'The Little Prince', author: 'Antoine De Saint-Exupery', price:800},
    { id: 3, imgUrl: "atomic.jpg", featured: false, title: 'Atomic Habits', author: 'James Clear', price:700},
    { id: 4, imgUrl: "food.jpg", featured: false, title: 'Real Food Cookbook', author: 'Nina Planck', price:600},
    { id: 5, imgUrl: "future.webp", featured: true, title: 'She Belongs to the Streets', author: 'Future', price:1500},
    { id: 6, imgUrl: "moby.jpg", featured: false, title: 'Moby Dick, or the Whale', author: 'Herman Melville', price:1250},
    { id: 7, imgUrl: "gatsby.jpg", featured: true, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', price:699},
    { id: 8, imgUrl: "mockingbird.jpg", featured: true, title: 'To Kill a Mockingbird', author: 'Harper Lee', price:350},
    { id: 9, imgUrl: "don.jpg", featured: false, title: 'Don Quixote', author: 'Miguel De Cervantes', price:299},
    { id: 10, imgUrl: "catch.jpg", featured: false, title: 'Catch-22', author: 'Joseph Heller', price:1500},
];
var cart = [];
app.get('/', (req, res) => {
    res.render('home', { books});
});

app.post('/cart/add', (req, res) => {
    const id = req.body;
    const book = books.find(b => b.id == id.bookId);
    const bookAdded = cart.find(c => c.id == book.id);
    if (bookAdded){
        bookAdded.quantity += 1;
    } else{
        cart.push({...book, quantity: 1});
    }
    res.sendStatus(200);
});
app.post('/cart/remove', (req, res) => {
    const id = req.body;
    const book = cart.find(c => c.id == id.bookId);
    if (book && book.quantity > 1){
        book.quantity -= 1;
    } else if (book.quantity == 1){
        const newCart = cart.filter(c => c.id != id.bookId);
        cart = newCart;
    }
    res.sendStatus(200);
})
app.post('/cart/clear', (req, res) => {
    cart = [];
    res.sendStatus(200); 
});
// app.get('/book/:id', (req, res) => {
//     const bookId = req.params.id;
//     const book = books.find(myBook => myBook.id == bookId);
//     res.render('book', { book });
// });
app.get('/book', (req, res) => {
    res.render('books', {books})
});
app.get('/cart', (req, res) => {
    res.render('cart', { cart });
});

app.listen(PORT, () =>{
    console.log(`Server running on http://localhost:${PORT}`);
});