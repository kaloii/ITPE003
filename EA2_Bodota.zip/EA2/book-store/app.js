const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();


app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, 'views'));




const books = [
    { id: 1, imgUrl: "romeoandjuliet.jpg", featured: false, title: "Romeo and Juliet", author: "William Shakespeare", price: 500 },
    { id: 2, imgUrl: "hamlet.jpg", featured: true, title: "Hamlet", author: "William Shakespeare", price: 350 },
    { id: 3, imgUrl: "henryv.jpg", featured: false, title: "Henry V", author: "William Shakespeare", price: 200 },
    { id: 4, imgUrl: "tempest.jpg", featured: false, title: 'The Tempest', author: 'William Shakespeare', price: 250 },
    { id: 5, imgUrl: "juliuscaeser.jpg", featured: true, title: 'Julius Caesar', author: 'William Shakespeare', price: 30 },
    { id: 6, imgUrl: "macbeth.jpg", featured: false, title: 'Macbeth', author: 'William Shakespeare', price: 750 },
    { id: 7, imgUrl: "Cymbeline.jpg", featured: true, title: 'Cymbeline', author: 'William Shakespeare', price: 500 },
    { id: 8, imgUrl: "Coriolanus.jpg", featured: true, title: 'Coriolanus', author: 'William Shakespeare', price: 450 },
];

let cart = [];
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));
app.use(bodyParser.json());
app.post('/cart/add', (req, res) => {
    const id = req.body;
    const book = books.find(b => b.id == id.bookId);

    if (book) {
        cart.push(book);
    }
    res.sendStatus(200);
});

app.get('/', (req, res) => {
    res.render('home', { books });
});

app.get('/book', (req, res) => {
    res.render('book', { books });
});

app.get('/cart', (req, res) => {
    const totalPrice = cart.reduce((acc, book) => acc + book.price, 0);
    res.render('cart', { cart, totalPrice });
});

app.post('/checkout', (req, res) => {
    cart = [];
    res.sendStatus(200);
});

const port = 3000;
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});